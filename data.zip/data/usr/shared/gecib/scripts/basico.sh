#!/bin/bash

# Copyright 2024-2024 GECIB
# Copyright 2024-2024 Jose Henrique da Silva <jose.henrique@brb.com.br>
#
# Este codigo eh de uso restrito à Gerencia de Monitoração e Resposta a Incidentes
# Cibernéticos - GECIB. A sua divulgacao ou utilizacao, sem previa autorizacao escrita,
# nao estah autorizada. Para mais informacoes, contacte a GECIB.
#
# Este script realiza a configuração básica de servidores de rede do GECIB.
#
# Para fazer a exclusão de determinadas configurações especiais em alguns
# servidores, crie o arquivo /etc/gecib-control com a linha
# EXCLUDE-OPTIONS=yes

PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin

REFERENCE="gecib-servers"

DIR_ROOT="/usr/share/${REFERENCE}"
DIR_BACK="/var/backups/${REFERENCE}"
DIR_ETC="/etc/${REFERENCE}"
DIR_ADM="/etc/adm"

FILES_CA="${DIR_ROOT}/ca"
FILES_CONFS="${DIR_ROOT}/confs"
FILES_CONFS_BASE="${DIR_ROOT}/confs-base-exemplos"
FILES_KEYS="${DIR_ROOT}/keys"
FILES_SCRIPTS="${DIR_ROOT}/scripts"


[ ! -e ${DIR_ADM} ] && mkdir ${DIR_ADM}
[ ! -e ${DIR_BACK} ] && mkdir ${DIR_BACK} 

[ -e ${DIR_ADM} ] && chmod 700 ${DIR_ADM}
[ -e ${DIR_BACK} ] && chmod 700 ${DIR_BACK}

function substituicao () {
    # Verifica existência de arquivo
    [ -e ${FILES_CONFS}/${FILE} ] || return

    AVERSION=$(cat ${DIR}/${FILE} | grep GECIB-VERSION | cut -d" " -f3)
    NVERSION=$(cat ${FILES_CONFS}/${FILE} | grep GECIB-VERSION | cut -d" " -f3)

    [ ${NVERSION} ] || return
    [ ${AVERSION}] && [ "${AVERSION}" -lt "${NVERSION}" ] && return

    echo -e "\n\n"
    backup
    [ -e ${DIR}/${FILE} ] && permissao || troca
    
}

# Faz backup de arquivos existentes
#
function backup() {
    DATE_TEMP=$(date '+%s')
    [ -e ${DIR}/${FILE} ] || return
    
    cp ${DIR}/${FILE} ${DIR_BACK}/${FILE}.${DATE_TEMP}
    chmod 000 ${DIR_BACK}/${FILE}.${DATE_TEMP}
    echo -e "Realizado backup de de ${DIR}/${FILE}."
    logger "GECIB - Realizado backup de ${DIR}/${FILE}."
}

# Realiza a troca dos arquivos
#
function troca() {
    echo -e "Alterando/Copiando o arquivo ${DIR}/${FILE}."
    logger "GECIB - Alterando/Copiando o arquivo ${DIR}/${FILE}."
    cp -f ${FILES_CONFS}/${FILE} ${DIR}/${FILE}
}

# Aplica as permissões no arquivo
#
function permissao() {
    PERMS1=$(stat -c "%a" ${DIR}/${FILE})
    OWNER1=$(stat -c "%U" ${DIR}/${FILE})
    GROUP1=$(stat -c "%G" ${DIR}/${FILE})

    troca

    chmod $PERMS1 ${DIR}/${FILE}
    chown $OWNER1:$GROUP1 ${DIR}/${FILE}
    echo -e "Aplicando as permissões necessárias no arquivo ${DIR}/${FILE}."
    logger "GECIB - Aplicando as permissões necessárias no arquivo ${DIR}/${FILE}."
}

# Criação de swap
#
if [ ! -e /swapfile ]; then
    echo -e "\n\nCriando arquivo de swap com 2GB."
    dd if=/dev/zero of=/swapfile bs=128M count=16
    mkswap -f /swapfile
    chmod 600 /swapfile
    echo "/swapfile  none  swap  sw  0  0" >> /etc/fstab
    swapon -a
    logger "GECIB - Criado arquivo de swap."
fi

# Remoção de usuários pre-existentes
#
USERS=$(ls /home)
if [ "${USERS}" ]; then
    for USER in ${USERS} ; do
        [[ ${USER} ]] || break
        if [ $(cat /etc/passwd | grep "${USER}") ]; then
            echo -e "\n\nRemovendo o usuário ${USER}."
            userdel -r ${USER}
            logger "GECIB - Removido o usuário ${USER}."
        fi
    done
fi

# Cópia de arquivos específicos para as bases (máquinas hospeiras).
#
TESTE=$(hostname | grep base-)
#
if [ "$TESTE" ]; then
    [ -e ${FILES_CONFS_BASE} ] || return
    MSG="\n\nGerando/Atualizando arquivos especificos de exemplo para servidores base.\n\n"
    echo -e "$MSG"
    cp -au ${FILES_CONFS_BASE} ${DIR_ADM}
    chmod 700 ${DIR_ADM}/confs-base-exemplos
fi
# Esta linha eliminará os arquivos nas bases e nas máquinas servidoras também
[ -e ${FILES_CONFS_BASE} ] && rm -rf ${FILES_CONFS_BASE}

# Substituição do /etc/default/grub
#
DIR=/etc/default
FILE=grub
substituicao

# Substituição do /etc/bash.bashrc
# sudo apt install linuxlogo
DIR=/etc
FILE=bash.bashrc
substituicao

# Substituição do /etc/ssh/sshd_config
#
DIR="/etc/ssh/sshd_config.d"
FILE="sshd_gecib.conf"
substituicao
[ -e ${DIR}/${FILE} ] && chmod 644 ${DIR}/${FILE}
[ -e ${DIR}/${FILE} ] && chown root:root ${DIR}/${FILE}
systemctl restart ssh

# Substituição do /etc/apt/sources.list
#
DIR=/etc/apt
FILE=sources.list
substituicao

# Substituição de chaves SSH, sem backup
#
DIR=/root/.ssh
FILE=authorized_keys

if [ ! -e "${DIR}/${FILE}" ]; then
    echo -e "\n\nCriando o arquivo ${DIR}/${FILE}.\n\n"
    mkdir -p ${DIR}
    chmod 700 ${DIR}
    > "${DIR}/${FILE}"
    logger "GECIB - Criado o arquivo ${DIR}/${FILE}"
fi
#
chattr -i ${DIR}/${FILE}
substituicao
chmod 400 ${DIR}/${FILE}
chattr +i ${DIR}/${FILE}
logger "GECIB - Substituido o arquivo ${DIR}/${FILE}"











BACKUPS=/var/backups/gecib-servers

CAFILE=${DIR_ROOT}/ca
CONFS=${DIR_ROOT}/confs
CONFSBASE=${DIR_ROOT}/confs-base-exemplos
CONTROL=/etc/gecib-servers
GPGKEYS=${DIR_ROOT}/keys
SCRIPTS=${DIR_ROOT}/scripts

# Exclusão de algumas configurações em máquinas diferentes
EXCLUSAO=$(cat /etc/cdciber-control | grep 'EXCLUDE-OPTIONS=yes')

# Teste sobre a necessidade de substituição de arquivos
#
function substituicao() {
    # Zera variável
    TROCA=0
    # Verifica existência de arquivo
    [ -e $DIR/$FILE ] || return
    # IVERSION = Versão Instalada
    IVERSION=$(cat $DIR/$FILE | grep GECIB-VERSION | cut -d" " -f3)
    [ ! $IVERSION ] && IVERSION=0
    # NVERSION = Versão Nova
    NVERSION=$(cat $CONFS/$FILE | grep GECIB-VERSION | cut -d" " -f3)
    # Decisão
    if [ "$IVERSION" -lt "$NVERSION" ]; then TROCA=1; fi
}
# Faz backup de arquivos existentes
#
function backup() {
    EPOCH=$(date '+%s')
    [ -e $DIR/$FILE ] || return
    cp $DIR/$FILE $BACKUPS/$FILE.$EPOCH
    chmod 000 $BACKUPS/$FILE.$EPOCH
    logger "GECIB - Realizado backup de $DIR/$FILE."
}
#
# Realiza a troca dos arquivos
#
function troca() {
    PERMS1=$(stat -c "%a" $DIR/$FILE)
    OWNER1=$(stat -c "%U" $DIR/$FILE)
    GROUP1=$(stat -c "%G" $DIR/$FILE)
    cp -f $CONFS/$FILE $DIR/$FILE
    chmod $PERMS1 $DIR/$FILE
    chown $OWNER1:$GROUP1 $DIR/$FILE
    logger "GECIB - Aplicando as permissões necessárias no arquivo $DIR/$FILE."
}
#
# Criação de swap
#
if [ ! -e /swapfile ]
then
    echo -e "\n\nCriando arquivo de swap com 2GB.\n\n"
    dd if=/dev/zero of=/swapfile bs=128M count=16
    mkswap -f /swapfile
    chmod 600 /swapfile
    echo "/swapfile  none  swap  sw  0  0" >> /etc/fstab
    swapon -a
    logger "GECIB - Criado arquivo de swap."
fi
#
# Remoção de usuários pre-existentes
#
USERS=$(ls /home)
#
if [ "${USERS}" ]; then
    for USER in ${USERS} ; do
        [[ ${USER} ]] || break
        if [ $(cat /etc/passwd | grep "${USER}") ]; then
            echo -e "\n\nRemovendo o usuário ${USER}.\n\n"
            userdel -r ${USER}
            logger "GECIB - Removido o usuário ${USER}."
        fi
    done
fi
# Cópia de arquivos específicos para as bases (máquinas hospeiras).
#
TESTE=$(hostname | grep base-)
#
if [ "$TESTE" ]
then
    MSG="\n\nGerando/Atualizando arquivos especificos de exemplo para servidores base.\n\n"
    [ -e /etc/adm ] || mkdir -p /etc/adm
    echo -e "$MSG"
    chmod 700 /etc/adm
    cp -au $CONFSBASE /etc/adm
    chmod 700 /etc/adm/confs-base-exemplos
fi
# Esta linha eliminará os arquivos nas bases e nas máquinas servidoras também
rm -rf $CONFSBASE
#
# Substituição do /etc/bash.bashrc
#
DIR=/etc
FILE=bash.bashrc
substituicao
#
if [ "$TROCA" -eq 1 ]
then
    echo -e "\n\nSubstituindo o arquivo $DIR/$FILE.\n\n"
    backup
    troca
    source $DIR/$FILE
    logger "CDCIBER - Substituido o arquivo $DIR/$FILE"
fi
#
# Substituição do /etc/ssh/sshd_config
#
NEW_SSH_DIR="/etc/ssh/sshd_config.d"
NEW_SSH_FILE="sshd_gecib.conf"
#
if [ -f "${NEW_SSH_DIR}/${NEW_SSH_FILE}" ]; then
    echo -e "\n\nAdicionando o arquivo ${NEW_SSH_DIR}/${NEW_SSH_FILE}.\n\n"
    cp -f $CONFS/${NEW_SSH_FILE} ${NEW_SSH_DIR}
    chmod 644 ${NEW_SSH_DIR}/${NEW_SSH_FILE}
    chown root:root ${NEW_SSH_DIR}/${NEW_SSH_FILE}
    logger "GECIB - Adicionando o arquivo ${NEW_SSH_DIR}/${NEW_SSH_FILE}"
    systemctl restart ssh
fi
#
# Substituição do /etc/apt/sources.list
#
DIR=/etc/apt
FILE=sources.list
substituicao
#
if [ "$TROCA" -eq 1 ] && [ ! "$EXCLUSAO" ]
then
    echo -e "\n\nSubstituindo o arquivo $DIR/$FILE.\n\n"
    backup
    troca
    logger "GECIB - Substituido o arquivo $DIR/$FILE"
fi
#
# Substituição do /etc/default/grub
#
DIR=/etc/default
FILE=grub
substituicao
#
if [ "$TROCA" -eq 1 ]
then
    echo -e "\n\nSubstituindo o arquivo $DIR/$FILE.\n\n"
    backup
    troca
    update-grub
    logger "GECIB - Substituido o arquivo $DIR/$FILE"
fi
#
# Substituição de chaves SSH, sem backup
#
DIR=/root/.ssh
FILE=authorized_keys

if [ ! -e "$DIR/$FILE" ] && [ ! "$EXCLUSAO" ]
then
    echo -e "\n\nCriando o arquivo $DIR/$FILE.\n\n"
    mkdir -p $DIR
    chmod 700 $DIR
    > $DIR/$FILE
    logger "GECIB - Criado o arquivo $DIR/$FILE"
fi
#
substituicao
#
if [ "$TROCA" -eq 1 ]
then
    echo -e "\n\nSubstituindo o arquivo $DIR/$FILE.\n\n"
    chattr -i $DIR/$FILE
    troca
    # Altera o arquivo, caso o servidor em questão seja da rede externa
        SERVERN=$(hostname | egrep '(stella|brian)')
        if [ "$SERVERN" ]
        then
          cat $DIR/$FILE | sed 's/^from="/from="177.15.130.90,/' > /tmp/$FILE
          mv /tmp/$FILE $DIR/$FILE
        fi
    chmod 400 $DIR/$FILE
    chattr +i $DIR/$FILE
    logger "GECIB - Substituido o arquivo $DIR/$FILE"
fi
# ****************************************
# Substituição do /etc/default/ntpdate
#
DIR=/etc/default
FILE=ntpdate
substituicao
#
if [ "$TROCA" -eq 1 ] && [ ! "$EXCLUSAO" ]
then
    echo -e "\n\nSubstituindo o arquivo $DIR/$FILE.\n\n"
    backup
    troca
    logger "GECIB - Substituido o arquivo $DIR/$FILE"
fi

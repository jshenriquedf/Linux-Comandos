#!/bin/bash

# Este script cria o arquivo /etc/gecib-backup-control, com a data atual, para o
# controle por parte do sistema de backup.
#
# Este arquivo deverá estar em cron.

PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin

DATACTRL=$(date '+%Y%m%d')
FILECTRL=/etc/gecib-backup-control

echo $DATACTRL > $FILECTRL
